
# do not import nose_testselector here - otherwise nose will become a direct
# dependency for all Agilo installations!

from agilo.test.testconfig import *
from agilo.test.testfinder import *
from agilo.test.test_env_helper import *
from agilo.test.testcase import *
from agilo.test.test_util import *

